<template>
    <div>
        <p><i  class="iconfont iconfangzi"></i>  Home component</p>
    </div>
</template>
<script>
export default {
  name: 'Home',
  data () {
    return {}
  }
}
</script>
<style>

</style>
