<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  data () {
    return {
    }
  }
}
</script>
<style  lang="less" scoped>
#app {
  height: 100%;
}
</style>
